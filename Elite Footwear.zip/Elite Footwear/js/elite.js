const products = [
  {

    name: "Adidas NMD R1",
    price: 104,
    brand: "Adidas",
    model: "NMD R1",
    color: "White",
    size: "37",
    category: "men",
    image: "./img/Adidas NMD_R1.png",
  },
  {
    name: "ASICS Gel-Nimbus 25",
    price: 133,
    brand: "ASICS",
    model: "Gel-Nimbus 25",
    color: "Black",
    size: "38",
    category: "unisex",
    image: "./img/ASICS Gel-Nimbus 25.png",
  },
  {
    name: "Brooks Ghost 14",
    price: 84,
    brand: "Brooks",
    model: "Ghost 14",
    color: "Blue",
    size: "39",
    category: "women",
    image: "./img/Brooks Ghost 14.png",
  },
  {
    name: "Clarks Desert Boot-2 Suede",
    price: 70,
    brand: "Clarks",
    model: "Desert Boot 2 Suede",
    color: "Brown",
    size: "40",
    category: "men",
    image: "./img/Clarks Desert Boot 2 Suede.png",
  },
  {
    name: "Clarks Linvale Jerica Pump",
    price: 64,
    brand: "Clarks",
    model: "Linvale Jerica Pump",
    color: "Black",
    size: "36",
    category: "women",
    image: "./img/Clarks Women's Linvale Jerica Pump.png",
  },
  {
    name: "Converse Chuck Taylor All Star",
    price: 70,
    brand: "All Star",
    model: "Converse Chuck Taylor",
    color: "Red",
    size: "38",
    category: "women",
    image: "./img/Converse Chuck Taylor All Star Hi.png",
  },
  {
    name: "Dr. Martens Smooth",
    price: 210,
    brand: "Dr. Martens",
    model: "1460 Smooth",
    color: "White",
    size: "39",
    category: "women",
    image: "./img/Dr. Martens 1460 Smooth.png",
  },
  {
    name: "Air Force 1 Low Louis Vuitton",
    price: 130,
    brand: "Louis Vuitton",
    model: "Air Force 1 Low",
    color: "Metallic Gold",
    size: "37",
    category: "men",
    image: "./img/Louis Vuitton Nike Air Force 1 Low.png",
  },
  {
    name: "Magnanni Marta",
    price: 340,
    brand: "Magnanni",
    model: "Marta",
    color: "Black",
    size: "40",
    category: "women",
    image: "./img/Magnanni Marta.png",
  },
  {
    name: "New Balance Fresh Foam",
    price: 100,
    brand: "New Balance",
    model: "Fresh Foam X 1080",
    color: "Blue",
    size: "38",
    category: "men",
    image: "./img/New Balance Fresh Foam X 1080 v12.png",
  },
  {
    name: "Nike Air Max 270",
    price: 110,
    brand: "Nike",
    model: "Air Force Max 270",
    color: "Black",
    size: "37",
    category: "women",
    image: "./img/Nike Air Max 270.png",
  },
  {
    name: "Nike Flex Control TR3",
    price: 50,
    brand: "Nike",
    model: "Men's Flex Control TR3 Sneaker",
    color: "White",
    size: "38",
    category: "men",
    image: "./img/Nike Men's Flex Control TR3 Sneaker.png",
  },
  {
    name: "Timberland Premium 6inch Waterproof Boot",
    price: 160,
    brand: "Timberland",
    model: "6inch Waterproof Boot",
    color: "Black",
    size: "39",
    category: "women",
    image: "./img/Premium 6inch Waterproof Boot.png",
  },
  {
    name: "Rebook Club Collegiate",
    price: 79,
    brand: "Rebook",
    model: "Club C 85 ID9265 Collegiate",
    color: "Brown",
    size: "37",
    category: "unisex",
    image: "./img/Rebook Club C 85 ID9265 Collegiate.png",
  },
  {
    name: "Reebok Classic Leather Legacy AZ",
    price: 49,
    brand: "Rebook",
    model: "Classic Leather Legacy AZ",
    color: "Blue",
    size: "36",
    category: "unisex",
    image: "./img/Reebok Classic Leather Legacy AZ.png",
  },
  {
    name: "Skechers Uno",
    price: 80,
    brand: "Skechers",
    model: "Uno-Stand On Air",
    color: "Black",
    size: "39",
    category: "men",
    image: "./img/Skechers Uno.png",
  },
  {
    name: "Tommy Hilfiger Essential Sneakers",
    price: 70,
    brand: "Tommy Hilfiger",
    model: "Essential Sneakers",
    color: "Blue",
    size: "36",
    category: "men",
    image: "./img/Tommy Hilfiger Essential Sneakers.png",
  },
  {
    name: "Vans Primary Check Old Skool",
    price: 45,
    brand: "Vans",
    model: "Old Skool",
    color: "Black",
    size: "38",
    category: "unisex",
    image: "./img/Vans Primary Check Old Skool Sneakers.png",
  },
  {
    name: "Wave Rider 25",
    price: 95,
    brand: "Mizuno",
    model: "Wave Rider 25",
    color: "Green",
    size: "39",
    category: "unisex",
    image: "./img/Wave Rider 25.png",
  },
  {
    name: "British Knights Dart",
    price: 60,
    brand: "British Knights",
    model: "Dart Sneaker",
    color: "Blue",
    size: "37",
    category: "unisex",
    image: "./img/British Knights Dart Sneaker.png",
  },
];

const productsContainer = document.getElementById("products");
const colorFilter = document.getElementById("color");
const sizeFilter = document.getElementById("size");

let selectedCategory = "all";

function filterByCategory(category) {
  selectedCategory = category;
  toggleSidebar();
  filterProducts();
}


function filterProducts() {
  const selectedColor = colorFilter.value;
  const selectedSize = sizeFilter.value;

  productsContainer.innerHTML = "";

  const filteredProducts = products.filter(product => {
    return (
      (selectedColor === "all" || product.color === selectedColor) &&
      (selectedSize === "all" || product.size === selectedSize) &&
      (selectedCategory === "all" || product.category === selectedCategory)
    );
  });


  filteredProducts.forEach(product => {
    const productCard = document.createElement("div");
    productCard.classList.add("product-card");
    productCard.innerHTML = `
    <img src="${product.image}" alt="${product.name}">
    <h3>${product.name}</h3>
    <div id="${product.name}" style="display: none;">
      <p>Brand: ${product.brand}</p>
      <p>Model: ${product.model}</p>
      <p>Price: $${product.price}</p>
      <p>Color: ${product.color}</p>
      <p>Size: ${product.size}</p>
      <p>Category: ${product.category}</p>
    </div>
    <button class="toggle-details" onclick="toggleDetails(this, '${product.name}')">Show Details</button>
    `;

    productsContainer.appendChild(productCard);
  });
}

function toggleSidebar() {
  const sidebar = document.querySelector('.sidebar');
  sidebar.classList.toggle('open');
}

function toggleDetails(button, productName) {

  const productDetails = document.getElementById(`${productName}`);
  console.log(productDetails);
  const buttonText = button.innerText;
  if (productDetails.style.display === 'none') {
    productDetails.style.display = 'block';
    button.innerText = 'Hide Details';
  } else {
    productDetails.style.display = 'none';
    button.innerText = 'Show Details';
  }
}

filterProducts();



